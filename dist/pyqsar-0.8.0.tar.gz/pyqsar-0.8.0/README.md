# pyqsar
 Refactor of pysqar for Python3

 Please see https://github.com/crong-k/pyqsar_tutorial for original package
